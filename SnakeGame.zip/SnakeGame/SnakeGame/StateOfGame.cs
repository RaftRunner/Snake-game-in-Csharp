﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnakeGame
{
	// Represents the current state of the Snake game
	public class StateOfGame
	{
		// Read-only properties for the grid dimensions (rows and columns)
		public int Rows { get; }
		public int Cols { get; }

		// 2D array representing the values in the grid (e.g., snake body, empty space, food)
		public GridValues[,] Grid { get; }

		// Stores the current direction of the snake (up, down, left, right)
		public DirectionInGrid Dir { get; private set; }

		// Player's score
		public int Score { get; private set; }

		// Flag to indicate if the game is over
		public bool GameOver { get; private set; }

		private readonly LinkedList<DirectionInGrid> dirChanges = new LinkedList<DirectionInGrid>();

		// Linked list to store the positions of the snake's body parts in the grid
		private readonly LinkedList<PositionInGrid> snakePositions = new LinkedList<PositionInGrid>();

		// Random number generator used to determine where food will spawn
		private readonly Random random = new Random();

		public StateOfGame(int rows, int cols)
		{
			Rows = rows;
			Cols = cols;
			Grid = new GridValues[rows, cols];
			Dir = DirectionInGrid.Right;

			AddSnake();
			AddFood();
		}

		private void AddSnake()
		{
			int r = Rows / 2;
			
			for (int c = 1; c<= 3; c++)
			{
				Grid[r, c] = GridValues.Snake;
				snakePositions.AddFirst(new PositionInGrid(r, c));
			}
		}

		private IEnumerable<PositionInGrid> EmptyPositions()
		{
			for (int r = 0; r < Rows; r++)
			{
				for (int c = 0; c < Cols; c++)
				{
					if (Grid[r,c] == GridValues.Empty)
					{
						yield return new PositionInGrid(r, c);
					}
				}
			}
		}

		private void AddFood()
		{
			List<PositionInGrid> empty = new List<PositionInGrid>(EmptyPositions());

			if (empty.Count == 0)
			{
				return;
			}

			PositionInGrid pos = empty[random.Next(empty.Count)];
			Grid[pos.Row, pos.Col] = GridValues.Food;
		}

		public PositionInGrid HeadPosition()
		{
			return snakePositions.First.Value;
		}

		public PositionInGrid TailPosition()
		{
			return snakePositions.Last.Value;
		}

		public IEnumerable<PositionInGrid> SnakePositions()
		{
			return snakePositions;
		}

		private void AddHead(PositionInGrid pos)
		{
			snakePositions.AddFirst(pos);
			Grid[pos.Row, pos.Col] = GridValues.Snake;
		}

		private void RemoveTail()
		{
			PositionInGrid tail = snakePositions.Last.Value;
			Grid[tail.Row, tail.Col] = GridValues.Empty;
			snakePositions.RemoveLast();
		}

		private DirectionInGrid GetLastDirection()
		{
			if (dirChanges.Count == 0)
			{
				return Dir;
			}

			return dirChanges.Last.Value;
		}

		private bool CanChangeDirection(DirectionInGrid newDir)
		{
			if(dirChanges.Count == 2)
			{
				return false;
			}

			DirectionInGrid lastDir = GetLastDirection();
			return newDir != lastDir && newDir != lastDir.Opposite();
		}

		public void ChangeDirection(DirectionInGrid direction)
		{
			if (CanChangeDirection(direction))
			{
				dirChanges.AddLast(direction);
			}
		}

		private bool OutsideGrid(PositionInGrid pos)
		{
			return pos.Row < 0 || pos.Row >= Rows || pos.Col < 0 || pos.Col >= Cols;
		}

		private GridValues WillHit(PositionInGrid newHeadPos)
		{
			if (OutsideGrid(newHeadPos))
			{
				return GridValues.Outside;
			}

			if (newHeadPos == TailPosition())
			{
				return GridValues.Empty;
			}

			return Grid[newHeadPos.Row, newHeadPos.Col];
		}

		public void Move()
		{
			if (dirChanges.Count > 0)
			{
				Dir = dirChanges.First.Value;
				dirChanges.RemoveFirst();
			}

			PositionInGrid newHeadPos = HeadPosition().Translate(Dir);
			GridValues hit = WillHit(newHeadPos);

			if (hit == GridValues.Outside || hit == GridValues.Snake)
			{
				GameOver = true;
			}
			else if ( hit == GridValues.Empty)
			{
				RemoveTail();
				AddHead(newHeadPos);
			}
			else if (hit == GridValues.Food)
			{
				AddHead(newHeadPos);
				Score++;
				AddFood();
			}
		}
	}
}
