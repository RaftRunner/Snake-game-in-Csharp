﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnakeGame
{
	// Represents a position in the grid (row and column)
	public class PositionInGrid
	{
		// Read-only properties for Row and Col (grid position)
		public int Row { get; }
		public int Col { get; }

		// Constructor to initialize a position in the grid with a row and column
		public PositionInGrid(int row, int col)
		{
			Row = row; // Assign the row value
			Col = col; // Assign the column value
		}

		// Translates the current position by applying a direction offset
		public PositionInGrid Translate(DirectionInGrid direction)
		{
			return new PositionInGrid(Row + direction.RowOffSet, Col + direction.ColOffSet);
		}

		// Overrides the Equals method to compare two PositionInGrid objects by their Row and Col
		public override bool Equals(object obj)
		{
			return obj is PositionInGrid grid &&
				   Row == grid.Row &&
				   Col == grid.Col;
		}

		// Overrides the GetHashCode method to provide a hash based on Row and Col
		public override int GetHashCode()
		{
			return HashCode.Combine(Row, Col);
		}

		// Overloads the == operator to compare two PositionInGrid objects for equality
		public static bool operator ==(PositionInGrid left, PositionInGrid right)
		{
			return EqualityComparer<PositionInGrid>.Default.Equals(left, right);
		}

		// Overloads the != operator to compare two PositionInGrid objects for inequality
		public static bool operator !=(PositionInGrid left, PositionInGrid right)
		{
			return !(left == right);
		}
	}
}
