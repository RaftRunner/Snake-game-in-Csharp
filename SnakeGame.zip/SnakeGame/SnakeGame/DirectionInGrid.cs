﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnakeGame
{
	// Represents a direction of movement in the grid
	public class DirectionInGrid
	{
		// Predefined directions: Left, Right, Up, and Down, each with respective row and column offsets
		public readonly static DirectionInGrid Left = new DirectionInGrid(0, -1);   // Move left by decreasing column
		public readonly static DirectionInGrid Right = new DirectionInGrid(0, 1);   // Move right by increasing column
		public readonly static DirectionInGrid Up = new DirectionInGrid(-1, 0);     // Move up by decreasing row
		public readonly static DirectionInGrid Down = new DirectionInGrid(1, 0);    // Move down by increasing row

		// Properties to get the row and column offsets for the movement
		public int RowOffSet { get; }
		public int ColOffSet { get; }

		// Private constructor so only predefined directions can be created
		private DirectionInGrid(int rowOffSet, int colOffSet)
		{
			RowOffSet = rowOffSet;    // Assign row offset for the movement
			ColOffSet = colOffSet;    // Assign column offset for the movement
		}

		// Method to return the opposite direction by inverting the row and column offsets
		public DirectionInGrid Opposite()
		{
			return new DirectionInGrid(-RowOffSet, -ColOffSet);
		}

		// Override Equals method to compare two DirectionInGrid objects based on row and column offsets
		public override bool Equals(object obj)
		{
			return obj is DirectionInGrid grid &&
				   RowOffSet == grid.RowOffSet &&
				   ColOffSet == grid.ColOffSet;
		}

		// Override GetHashCode to return a unique hash for each direction based on its offsets
		public override int GetHashCode()
		{
			return HashCode.Combine(RowOffSet, ColOffSet);
		}

		// Overloading the == operator to check if two directions are the same
		public static bool operator ==(DirectionInGrid left, DirectionInGrid right)
		{
			return EqualityComparer<DirectionInGrid>.Default.Equals(left, right);
		}

		// Overloading the != operator to check if two directions are different
		public static bool operator !=(DirectionInGrid left, DirectionInGrid right)
		{
			return !(left == right);
		}
	}
}
